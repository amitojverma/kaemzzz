package com.cts.bookShopping.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bookShopping.bean.Books;
import com.cts.bookShopping.bean.Category;
import com.cts.bookShopping.service.BooksService;
import com.cts.bookShopping.service.CategoryService;



@Controller
public class BooksController {
	@Autowired
	BooksService booksService;
	
	@Autowired
	CategoryService categoryService;
	
	@RequestMapping("adminHomepage.html")
	public String getBooks(){
		return "adminHomepage";
	}
	
	
	
	@RequestMapping("addproduct.html")
	public String addBooks(){
		return "addproduct";
	}
	
	
	@RequestMapping(value="booksadded.html",method = RequestMethod.POST)
	public String addBook(@ModelAttribute Books books,HttpSession httpSession){
		//session
		
		ModelAndView modelAndView = new ModelAndView();
		
		
		if("true".equals(booksService.insertBook(books)))
		{
			System.out.println(books);
			
			return "addproduct";
		}
		else
		{
			return null;
		}
		
	}
	@RequestMapping(value="addproduct.html",method = RequestMethod.POST)
	public String viewCategory(@ModelAttribute Category category){
		ModelAndView modelAndView = new ModelAndView();
		List<Category> list = categoryService.getAllCategory();
		System.out.println(list);
		modelAndView.addObject("category",list);
		return null;
	}
	//booksadded.html
	
	/*
	@RequestMapping("productAddSuccess.html")
	public ModelAndView displayCategory(@ModelAttribute Books product){
		
		ModelAndView modelAndView = new ModelAndView();
		List<com.cts.bookShopping.bean.Category> category = categoryService.getCategoryName();
		System.out.println(category);
		modelAndView.addObject("category", category);
		//modelAndView.setViewName("Admin-AddProduct");
		return modelAndView;
		
	}*/
}
