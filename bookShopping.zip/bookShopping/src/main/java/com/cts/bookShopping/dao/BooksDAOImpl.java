package com.cts.bookShopping.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.Books;


@Repository("booksDAO")
public class BooksDAOImpl implements BooksDAO{

	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;
	@Transactional
	public String insertBook(Books books) {
		Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		session.save(books);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		
		return "false";
	}

	@Transactional
	public String deleteBook(String id) {
		Session session = null;
		String query= "from books where bookId = ?";
		Query<Books> query2=null;
		try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, id);
			Books books = query2.getSingleResult();
			session.delete(books);
				return "true";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Transactional
	public String updateBook(Books books) {
		Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		//transaction = session.getTransaction();
		//transaction.begin();
		
		session.update(books);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		return null;
	}

	@Transactional
	public Books getBookById(String id) {
Session session = null;
		
		String query= "from books where bookId = ?";
	Query<Books> query2=null;
		try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, id);
			Books books = query2.getSingleResult();
			if(books==null)
				return null;
			else
				return books;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Transactional
	public List<Books> getAllBook() {
		Session session = null;
		
	      try {
	    	  String query= "from books";
	    		Query<Books> query2=null;
	    			
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<Books> books = query2.getResultList();
	    				if(books==null)
	    					return null;
	    				else
	    					return books;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
	      
		return null;
	}

	@Transactional
	public Books getBookByName(String name) {
Session session = null;
		
		String query= "from books where bookName = ?";
	Query<Books> query2=null;
		try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, name);
			Books product = query2.getSingleResult();
			if(product==null)
				return null;
			else
				return product;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Transactional
	public List<Books> getDescBook() {
		Session session = null;
		
	      try {
	    	  String query= "from books order by bookName DESC";
	    		Query<Books> query2=null;
	    			
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<Books> products = query2.getResultList();
	    				if(products==null)
	    					return null;
	    				else
	    					return products;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
	      
		return null;
	}

	@Transactional
	public List<Books> getAscBook() {
		Session session = null;
		
	      try {
	    	  String query= "from books order by bookName";
	    		Query<Books> query2=null;
	    			
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<Books> products = query2.getResultList();
	    				if(products==null)
	    					return null;
	    				else
	    					return products;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
		return null;
	}

	
	

}
