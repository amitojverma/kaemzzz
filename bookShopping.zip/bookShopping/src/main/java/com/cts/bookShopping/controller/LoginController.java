package com.cts.bookShopping.controller;
import com.cts.bookShopping.bean.login;
import com.cts.bookShopping.bean.userRegistration;
import com.cts.bookShopping.service.LoginService;
import com.cts.bookShopping.service.LoginService.*;
import com.cts.bookShopping.service.RegisterationService;


import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class LoginController {
	

	@Autowired
	LoginService loginService;
	
	@Autowired
	RegisterationService registrationService;


	@RequestMapping("login.html")
	public String getLoginPage(){                                        
		return "login";
	}

	@RequestMapping(value="login.html",method = RequestMethod.POST)
	public ModelAndView validateUser(@ModelAttribute login login1){
		ModelAndView modelAndView = new ModelAndView();
		//registrationService login2 = loginService.authenticate(login1.getEmailId(), login1.getPassword());
		if("admin".equals(login1.getPassword()))
		{
			System.out.println("Checkpoint1");
			modelAndView.setViewName("adminHomepage");
		}
		else if(loginService.authenticate(login1.getEmailId(),login1.getPassword()) != null)
		{
			modelAndView.setViewName("home");
		}
		else 
		{
			modelAndView.setViewName("login");
		}
		return modelAndView;
	}
	
	@RequestMapping("userRegistration12.html")
	public String getRegisterationPage(){
		return "userRegistration";
	}

	


	
}
