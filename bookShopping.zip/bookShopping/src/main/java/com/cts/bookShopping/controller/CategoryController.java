/*package com.cts.bookShopping.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.bookShopping.bean.Books;
import com.cts.bookShopping.bean.Category;
import com.cts.bookShopping.service.CategoryService;

@Controller
public class CategoryController {
	@Autowired
	CategoryService categoryService;
	@RequestMapping("addproduct.html")
	public String addBooks(){
		return "addproduct";
	}
	@RequestMapping(value="addproduct.html",method = RequestMethod.POST)
	public String viewCategory(@ModelAttribute Category category){
		ModelAndView modelAndView = new ModelAndView();
		List<Category> list = categoryService.getAllCategory();
		modelAndView.addObject("cat",list);
		return null;
	}
}*/
